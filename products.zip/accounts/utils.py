import openpyxl
import datetime
import decimal
from .models import Region, City, Product


def format_text(text):
    """
    Formats the text based on the following rules:
    - If the text has exactly three words:
        * The first and second words: capitalize the first letter and lowercase the rest (even handling parts separated by apostrophes).
        * The third word: all lowercased (handling apostrophes as well).
    - Otherwise:
        * The first word: capitalize the first letter and lowercase the rest (handling apostrophes).
        * All other words: lowercased (handling apostrophes).
    """
    words = text.split()
    if not words:
        return ""

    def format_word_cap(word):
        parts = word.split("'")
        formatted_parts = [parts[0].capitalize()] + [p.lower() for p in parts[1:]]
        return "'".join(formatted_parts)

    def format_word_lower(word):
        parts = word.split("'")
        return "'".join([p.lower() for p in parts])

    formatted_words = []
    if len(words) == 3:
        formatted_words.append(format_word_cap(words[0]))
        formatted_words.append(format_word_cap(words[1]))
        formatted_words.append(format_word_lower(words[2]))
    else:
        formatted_words.append(format_word_cap(words[0]))
        for word in words[1:]:
            formatted_words.append(format_word_lower(word))
    return " ".join(formatted_words)


def import_products_from_excel(excel_file):
    """
    Import products from an Excel file using openpyxl.
    Assumes data starts from row 2 with the following fixed column indices:
      0: Serial number (ignored)
      1: Order status ("确认订单" => confirmed, else pending)
      2: Date (e.g., "2025-01-06 23:59:34")
      3: Order number
      4: Weight (string with comma as decimal separator or a float)
      5: English product name
      6: Chinese product name (ignored)
      7: Address (ignored or included if needed)
      8: City (if text contains '/', use part after '/' then format it)
      9: Region (if text contains '/', use part after '/' then format it)
     10: Phone number

    Returns a list of messages describing the result.
    """
    wb = openpyxl.load_workbook(excel_file)
    ws = wb.active
    messages = []
    imported_count = 0

    for row in ws.iter_rows(min_row=2, values_only=True):
        try:
            date_str = row[2]
            order_number = row[3]
            weight_raw = row[4]
            address = row[7]
            city_field = row[8]
            region_field = row[9]
            phone = row[10]

            # Convert weight:
            if weight_raw is not None:
                if isinstance(weight_raw, str):
                    weight_str = weight_raw.replace(',', '.')
                else:
                    weight_str = str(weight_raw)
            else:
                weight_str = "0"
            weight = decimal.Decimal(weight_str)

            try:
                date_obj = datetime.datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
            except Exception as e:
                messages.append(f"Error parsing date {date_str} for order {order_number}: {e}")
                continue

            # Process city: if city_field is a string with '/', use part after slash
            if city_field and isinstance(city_field, str):
                if '/' in city_field:
                    raw_city = city_field.split('/')[-1].strip()
                else:
                    raw_city = city_field.strip()
                city_name = format_text(raw_city)
            else:
                city_name = None

            # Process region similarly:
            if region_field and isinstance(region_field, str):
                if '/' in region_field:
                    raw_region = region_field.split('/')[-1].strip()
                else:
                    raw_region = region_field.strip()
                region_name = format_text(raw_region)
            else:
                region_name = None

            if phone and not phone.startswith('+998'):
                phone = '+998' + phone.strip()

            # Get or create Region:
            region_obj = None
            if region_name:
                region_obj, _ = Region.objects.get_or_create(name=region_name)
            # Get or create City (if region exists):
            city_obj = None
            if city_name and region_obj:
                city_obj, _ = City.objects.get_or_create(name=city_name, region=region_obj)

            product, created = Product.objects.get_or_create(
                order_number=order_number,
                defaults={
                    'date': date_obj,
                    'weight': weight,
                    'address': address,
                    'city': city_obj,
                    'region': region_obj,
                    'phone_number': phone,
                }
            )
            if created:
                imported_count += 1
            else:
                messages.append(f"Product {order_number} already exists.")
        except Exception as e:
            messages.append(f"Error processing row for order {order_number}: {e}")
            continue

    messages.append(f"Imported {imported_count} products successfully.")
    return messages
