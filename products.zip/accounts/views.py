from rest_framework import generics
from django.contrib.auth import get_user_model, authenticate
from rest_framework import permissions, status, views, viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.parsers import FileUploadParser
import openpyxl
import datetime
from django.http import HttpResponse

from .serializers import (
    UserRegistrationSerializer,
    UserSerializer,
    CourierSerializer,
    ProductSerializer,
    CitySerializer,
    RegionSerializer,
    CourierCreateSerializer
)
from .permissions import IsAdminOrCourierBoss, IsAdmin, IsCourierBoss
from .models import Courier, Product, Region, City

User = get_user_model()


# ---------------------------
# Excel File Upload View using openpyxl
# ---------------------------
class FileUploadView(APIView):
    """
    Upload an Excel file to import Products.

    Expected Excel columns (starting at row 2):
      0: 序号             -> Serial Number (ignored or used if needed)
      1: 状态             -> Order Status (e.g., "确认订单" will be mapped to "confirmed")
      2: 创建日期         -> Creation Date (either a datetime or string formatted as 'YYYY-MM-DD HH:MM:SS')
      3: 转单号           -> Order Number
      4: 重量             -> Weight (e.g., "1,43" will be converted to 1.43)
      5: 英文品名         -> Product Name in English
      6: 中文品名         -> Product Name in Chinese
      7: 发件人地址       -> Sender Address
      8: 发件人城市       -> City (if contains '/', use the part after the slash)
      9: 发件人洲省       -> Region (if contains '/', use the part after the slash)
      10: 发件人电话      -> Phone Number
    """
    parser_classes = (FileUploadParser,)

    def post(self, request, *args, **kwargs):
        file_obj = request.data.get('file')
        if not file_obj:
            return Response({"error": "No file provided."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            wb = openpyxl.load_workbook(file_obj)
        except Exception as e:
            return Response({"error": f"Error reading Excel file: {e}"}, status=status.HTTP_400_BAD_REQUEST)

        ws = wb.active
        imported_count = 0

        # Iterate over rows, starting at row 2 (skip header)
        for row in ws.iter_rows(min_row=2, values_only=True):
            try:
                # Column mapping:
                # 0: 序号, 1: 状态, 2: 创建日期, 3: 转单号, 4: 重量, 5: 英文品名, 6: 中文品名, 7: 发件人地址, 8: 发件人城市, 9: 发件人洲省, 10: 发件人电话
                order_number = str(row[3])
                order_status = "confirmed" if row[1] == "确认订单" else "pending"

                creation_date = row[2]
                if isinstance(creation_date, str):
                    try:
                        creation_date = datetime.datetime.strptime(creation_date, '%Y-%m-%d %H:%M:%S')
                    except Exception:
                        creation_date = None

                # Convert weight: if string, replace comma with dot
                weight_raw = row[4]
                if isinstance(weight_raw, str):
                    weight_val = float(weight_raw.replace(',', '.'))
                else:
                    weight_val = weight_raw

                product_name_en = str(row[5])
                product_name_cn = str(row[6])
                sender_address = row[7]

                # Parse city: if '/' is present, take the part after the slash; otherwise, use the full string.
                city_field = row[8]
                if isinstance(city_field, str) and '/' in city_field:
                    city_name = city_field.split('/', 1)[1].strip()
                else:
                    city_name = str(city_field).strip()

                # Parse region similarly.
                region_field = row[9]
                if isinstance(region_field, str) and '/' in region_field:
                    region_name = region_field.split('/', 1)[1].strip()
                else:
                    region_name = str(region_field).strip()

                phone_number = str(row[10])

                # Get or create City and Region instances.
                city_obj, _ = City.objects.get_or_create(name=city_name)
                region_obj, _ = Region.objects.get_or_create(name=region_name)

                # Create the Product object.
                Product.objects.create(
                    order_number=order_number,
                    order_status=order_status,
                    creation_date=creation_date,
                    weight=weight_val,
                    product_name_en=product_name_en,
                    product_name_cn=product_name_cn,
                    sender_address=sender_address,
                    city=city_obj,
                    region=region_obj,
                    phone_number=phone_number,
                    temu_status='new',  # Set initial status if applicable.
                )
                imported_count += 1
            except Exception as e:
                # Optionally log the error e here.
                continue

        return Response(
            {"message": f"Imported {imported_count} products successfully."},
            status=status.HTTP_201_CREATED
        )


# ---------------------------
# User Registration & Authentication Endpoints
# ---------------------------
class RegisterView(APIView):
    permission_classes = (permissions.AllowAny,)

    def post(self, request):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({'user': UserSerializer(user).data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class LoginView(APIView):
    permission_classes = (permissions.AllowAny,)

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            tokens = get_tokens_for_user(user)
            return Response(tokens, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid Credentials'}, status=status.HTTP_401_UNAUTHORIZED)


class LogoutView(APIView):
    def post(self, request):
        try:
            refresh_token = request.data["refresh"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response(status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)


# ---------------------------
# ViewSets for City, Region, Courier, and Product
# ---------------------------
class CityViewSet(viewsets.ModelViewSet):
    queryset = City.objects.all()
    serializer_class = CitySerializer


class RegionViewSet(viewsets.ModelViewSet):
    queryset = Region.objects.all()
    serializer_class = RegionSerializer


class CourierViewSet(viewsets.ModelViewSet):
    queryset = Courier.objects.all()
    serializer_class = CourierSerializer
    permission_classes = [IsAdminOrCourierBoss]

    def perform_create(self, serializer):
        if self.request.user.role == 'Courier Boss':
            serializer.save()


class CourierCreateAPIView(generics.CreateAPIView):
    """
    API view to create a new courier. The serializer uses a custom
    CourierCreationForm internally to create the associated user and courier.
    """
    queryset = Courier.objects.all()
    serializer_class = CourierCreateSerializer


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAdminOrCourierBoss]

    def perform_create(self, serializer):
        if self.request.user.role == 'Courier Boss':
            # Ensure the Courier Boss can only assign to couriers in covered cities
            courier_id = serializer.validated_data['assigned_to'].id
            courier = Courier.objects.get(id=courier_id)
            if courier.covered_cities.filter(id__in=self.request.user.courier.covered_cities.all()).exists():
                serializer.save()
            else:
                raise permissions.PermissionDenied("This courier does not cover the required city.")


class AssignProductView(APIView):
    permission_classes = [IsCourierBoss]

    def post(self, request):
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


def home(request):
    return HttpResponse("Welcome to my Django project!")